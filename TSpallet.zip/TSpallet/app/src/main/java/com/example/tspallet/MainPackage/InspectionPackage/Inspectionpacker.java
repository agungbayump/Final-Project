package com.example.tspallet.MainPackage.InspectionPackage;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.tspallet.R;

public class Inspectionpacker extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inspectionpacker);
    }
}
