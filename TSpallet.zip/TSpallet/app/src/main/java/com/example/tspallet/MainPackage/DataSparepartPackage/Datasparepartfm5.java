package com.example.tspallet.MainPackage.DataSparepartPackage;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.tspallet.R;

public class Datasparepartfm5 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_datasparepartfm5);
    }
}
