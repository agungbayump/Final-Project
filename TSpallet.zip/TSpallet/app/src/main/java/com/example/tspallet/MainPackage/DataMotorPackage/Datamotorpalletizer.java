package com.example.tspallet.MainPackage.DataMotorPackage;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.tspallet.R;

public class Datamotorpalletizer extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_datamotorpalletizer);
    }
}
