package com.example.tspallet.MainPackage.TroubleshootingPackage;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.tspallet.R;

public class Troubleshootingpacker extends AppCompatActivity {

    CardView s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, s12, s13,s14,s15,s16,s17;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_troubleshootingpacker);

        s1 = (CardView) findViewById(R.id.f258step1);
        s2 = (CardView) findViewById(R.id.f258step2);
        s3 = (CardView) findViewById(R.id.f258step3);
        s4 = (CardView) findViewById(R.id.f258step4);
        s5 = (CardView) findViewById(R.id.f258step5);
        s6 = (CardView) findViewById(R.id.f258step6);
        s7 = (CardView) findViewById(R.id.f258step7);
        s8 = (CardView) findViewById(R.id.f258step8);
        s9 = (CardView) findViewById(R.id.f258step9);
        s10 = (CardView) findViewById(R.id.f258step10);
        s11 = (CardView) findViewById(R.id.f258step11);
        s12 = (CardView) findViewById(R.id.f258step12);
        s13 = (CardView) findViewById(R.id.f258step13);
        s14 = (CardView) findViewById(R.id.f258step14);
        s15 = (CardView) findViewById(R.id.f258step15);
        s16 = (CardView) findViewById(R.id.f258step16);
        s17 = (CardView) findViewById(R.id.f258step17);

    }

    public void yes1click(View view) {
        s1.setVisibility(View.VISIBLE);
        s2.setVisibility(View.GONE);
        s3.setVisibility(View.GONE);
        s4.setVisibility(View.VISIBLE);
        s5.setVisibility(View.GONE);
        s6.setVisibility(View.GONE);
        s7.setVisibility(View.GONE);
        s8.setVisibility(View.GONE);
        s9.setVisibility(View.GONE);
        s10.setVisibility(View.GONE);
        s11.setVisibility(View.GONE);
        s12.setVisibility(View.GONE);
        s13.setVisibility(View.GONE);
        s14.setVisibility(View.GONE);
        s15.setVisibility(View.GONE);
        s16.setVisibility(View.GONE);
        s17.setVisibility(View.GONE);

    }

    public void no1click(View view) {
        s1.setVisibility(View.VISIBLE);
        s2.setVisibility(View.VISIBLE);
        s3.setVisibility(View.GONE);
        s4.setVisibility(View.GONE);
        s5.setVisibility(View.GONE);
        s6.setVisibility(View.GONE);
        s7.setVisibility(View.GONE);
        s8.setVisibility(View.GONE);
        s9.setVisibility(View.GONE);
        s10.setVisibility(View.GONE);
        s11.setVisibility(View.GONE);
        s12.setVisibility(View.GONE);
        s13.setVisibility(View.GONE);
        s14.setVisibility(View.GONE);
        s15.setVisibility(View.GONE);
        s16.setVisibility(View.GONE);
        s17.setVisibility(View.GONE);

    }

    public void yes2click(View view) {
        s1.setVisibility(View.VISIBLE);
        s2.setVisibility(View.VISIBLE);
        s3.setVisibility(View.VISIBLE);
        s4.setVisibility(View.GONE);
        s5.setVisibility(View.GONE);
        s6.setVisibility(View.GONE);
        s7.setVisibility(View.GONE);
        s8.setVisibility(View.GONE);
        s9.setVisibility(View.GONE);
        s10.setVisibility(View.GONE);
        s11.setVisibility(View.GONE);
        s12.setVisibility(View.GONE);
        s13.setVisibility(View.GONE);
        s14.setVisibility(View.GONE);
        s15.setVisibility(View.GONE);
        s16.setVisibility(View.GONE);
        s17.setVisibility(View.GONE);

    }

    public void no2click(View view) {
        s1.setVisibility(View.VISIBLE);
        s2.setVisibility(View.VISIBLE);
        s3.setVisibility(View.GONE);
        s4.setVisibility(View.GONE);
        s5.setVisibility(View.GONE);
        s6.setVisibility(View.VISIBLE);
        s7.setVisibility(View.GONE);
        s8.setVisibility(View.GONE);
        s9.setVisibility(View.GONE);
        s10.setVisibility(View.GONE);
        s11.setVisibility(View.GONE);
        s12.setVisibility(View.GONE);
        s13.setVisibility(View.GONE);
        s14.setVisibility(View.GONE);
        s15.setVisibility(View.GONE);
        s16.setVisibility(View.GONE);
        s17.setVisibility(View.GONE);

    }

    public void yes3click(View view) {
        s1.setVisibility(View.VISIBLE);
        s2.setVisibility(View.VISIBLE);
        s3.setVisibility(View.VISIBLE);
        s4.setVisibility(View.GONE);
        s5.setVisibility(View.GONE);
        s6.setVisibility(View.GONE);
        s7.setVisibility(View.GONE);
        s8.setVisibility(View.GONE);
        s9.setVisibility(View.GONE);
        s10.setVisibility(View.GONE);
        s11.setVisibility(View.GONE);
        s12.setVisibility(View.GONE);
        s13.setVisibility(View.GONE);
        s14.setVisibility(View.VISIBLE);
        s15.setVisibility(View.GONE);
        s16.setVisibility(View.GONE);
        s17.setVisibility(View.GONE);

    }

    public void no3click(View view) {
        s1.setVisibility(View.VISIBLE);
        s2.setVisibility(View.VISIBLE);
        s3.setVisibility(View.VISIBLE);
        s4.setVisibility(View.GONE);
        s5.setVisibility(View.GONE);
        s6.setVisibility(View.VISIBLE);
        s7.setVisibility(View.GONE);
        s8.setVisibility(View.GONE);
        s9.setVisibility(View.GONE);
        s10.setVisibility(View.GONE);
        s11.setVisibility(View.GONE);
        s12.setVisibility(View.GONE);
        s13.setVisibility(View.GONE);
        s14.setVisibility(View.GONE);
        s15.setVisibility(View.GONE);
        s16.setVisibility(View.GONE);
        s17.setVisibility(View.GONE);

    }

    public void yes4click(View view) {
        s1.setVisibility(View.VISIBLE);
        s2.setVisibility(View.GONE);
        s3.setVisibility(View.GONE);
        s4.setVisibility(View.VISIBLE);
        s5.setVisibility(View.GONE);
        s6.setVisibility(View.VISIBLE);
        s7.setVisibility(View.GONE);
        s8.setVisibility(View.GONE);
        s9.setVisibility(View.GONE);
        s10.setVisibility(View.GONE);
        s11.setVisibility(View.GONE);
        s12.setVisibility(View.GONE);
        s13.setVisibility(View.GONE);
        s14.setVisibility(View.GONE);
        s15.setVisibility(View.GONE);
        s16.setVisibility(View.GONE);
        s17.setVisibility(View.GONE);

    }

    public void no4click(View view) {
        s1.setVisibility(View.VISIBLE);
        s2.setVisibility(View.GONE);
        s3.setVisibility(View.GONE);
        s4.setVisibility(View.VISIBLE);
        s5.setVisibility(View.VISIBLE);
        s6.setVisibility(View.GONE);
        s7.setVisibility(View.GONE);
        s8.setVisibility(View.GONE);
        s9.setVisibility(View.GONE);
        s10.setVisibility(View.GONE);
        s11.setVisibility(View.GONE);
        s12.setVisibility(View.GONE);
        s13.setVisibility(View.GONE);
        s14.setVisibility(View.GONE);
        s15.setVisibility(View.GONE);
        s16.setVisibility(View.GONE);
        s17.setVisibility(View.GONE);

    }

    public void yes5click(View view) {
        s1.setVisibility(View.VISIBLE);
        s2.setVisibility(View.GONE);
        s3.setVisibility(View.GONE);
        s4.setVisibility(View.VISIBLE);
        s5.setVisibility(View.VISIBLE);
        s6.setVisibility(View.GONE);
        s7.setVisibility(View.GONE);
        s8.setVisibility(View.GONE);
        s9.setVisibility(View.GONE);
        s10.setVisibility(View.GONE);
        s11.setVisibility(View.GONE);
        s12.setVisibility(View.GONE);
        s13.setVisibility(View.GONE);
        s14.setVisibility(View.GONE);
        s15.setVisibility(View.VISIBLE);
        s16.setVisibility(View.GONE);
        s17.setVisibility(View.GONE);


    }

    public void no5click(View view) {
        s1.setVisibility(View.VISIBLE);
        s2.setVisibility(View.GONE);
        s3.setVisibility(View.GONE);
        s4.setVisibility(View.VISIBLE);
        s5.setVisibility(View.VISIBLE);
        s6.setVisibility(View.VISIBLE);
        s7.setVisibility(View.GONE);
        s8.setVisibility(View.GONE);
        s9.setVisibility(View.GONE);
        s10.setVisibility(View.GONE);
        s11.setVisibility(View.GONE);
        s12.setVisibility(View.GONE);
        s13.setVisibility(View.GONE);
        s14.setVisibility(View.GONE);
        s15.setVisibility(View.GONE);
        s16.setVisibility(View.GONE);
        s17.setVisibility(View.GONE);

    }

    public void yes6click(View view) {
        s1.setVisibility(View.VISIBLE);
        s2.setVisibility(View.GONE);
        s3.setVisibility(View.GONE);
        s4.setVisibility(View.VISIBLE);
        s5.setVisibility(View.VISIBLE);
        s6.setVisibility(View.VISIBLE);
        s7.setVisibility(View.GONE);
        s8.setVisibility(View.GONE);
        s9.setVisibility(View.GONE);
        s10.setVisibility(View.GONE);
        s11.setVisibility(View.GONE);
        s12.setVisibility(View.GONE);
        s13.setVisibility(View.VISIBLE);
        s14.setVisibility(View.GONE);
        s15.setVisibility(View.GONE);
        s16.setVisibility(View.GONE);
        s17.setVisibility(View.GONE);

    }

    public void no6click(View view) {
        s1.setVisibility(View.VISIBLE);
        s2.setVisibility(View.GONE);
        s3.setVisibility(View.GONE);
        s4.setVisibility(View.VISIBLE);
        s5.setVisibility(View.VISIBLE);
        s6.setVisibility(View.VISIBLE);
        s7.setVisibility(View.VISIBLE);
        s8.setVisibility(View.GONE);
        s9.setVisibility(View.GONE);
        s10.setVisibility(View.GONE);
        s11.setVisibility(View.GONE);
        s12.setVisibility(View.GONE);
        s13.setVisibility(View.GONE);
        s14.setVisibility(View.GONE);
        s15.setVisibility(View.GONE);
        s16.setVisibility(View.GONE);
        s17.setVisibility(View.GONE);

    }

    public void yes7click(View view) {
        s1.setVisibility(View.VISIBLE);
        s2.setVisibility(View.GONE);
        s3.setVisibility(View.GONE);
        s4.setVisibility(View.VISIBLE);
        s5.setVisibility(View.VISIBLE);
        s6.setVisibility(View.VISIBLE);
        s7.setVisibility(View.VISIBLE);
        s8.setVisibility(View.GONE);
        s9.setVisibility(View.GONE);
        s10.setVisibility(View.GONE);
        s11.setVisibility(View.GONE);
        s12.setVisibility(View.VISIBLE);
        s13.setVisibility(View.GONE);
        s14.setVisibility(View.GONE);
        s15.setVisibility(View.GONE);
        s16.setVisibility(View.GONE);
        s17.setVisibility(View.GONE);

    }

    public void no7click(View view) {
        s1.setVisibility(View.VISIBLE);
        s2.setVisibility(View.GONE);
        s3.setVisibility(View.GONE);
        s4.setVisibility(View.VISIBLE);
        s5.setVisibility(View.VISIBLE);
        s6.setVisibility(View.VISIBLE);
        s7.setVisibility(View.VISIBLE);
        s8.setVisibility(View.VISIBLE);
        s9.setVisibility(View.GONE);
        s10.setVisibility(View.GONE);
        s11.setVisibility(View.GONE);
        s12.setVisibility(View.GONE);
        s13.setVisibility(View.GONE);
        s14.setVisibility(View.GONE);
        s15.setVisibility(View.GONE);
        s16.setVisibility(View.GONE);
        s17.setVisibility(View.GONE);

    }

    public void yes8click(View view) {
        s1.setVisibility(View.VISIBLE);
        s2.setVisibility(View.GONE);
        s3.setVisibility(View.GONE);
        s4.setVisibility(View.VISIBLE);
        s5.setVisibility(View.VISIBLE);
        s6.setVisibility(View.VISIBLE);
        s7.setVisibility(View.VISIBLE);
        s8.setVisibility(View.VISIBLE);
        s9.setVisibility(View.GONE);
        s10.setVisibility(View.GONE);
        s11.setVisibility(View.GONE);
        s12.setVisibility(View.GONE);
        s13.setVisibility(View.VISIBLE);
        s14.setVisibility(View.GONE);
        s15.setVisibility(View.GONE);
        s16.setVisibility(View.GONE);
        s17.setVisibility(View.GONE);

    }

    public void no8click(View view) {
        s1.setVisibility(View.VISIBLE);
        s2.setVisibility(View.GONE);
        s3.setVisibility(View.GONE);
        s4.setVisibility(View.VISIBLE);
        s5.setVisibility(View.VISIBLE);
        s6.setVisibility(View.VISIBLE);
        s7.setVisibility(View.VISIBLE);
        s8.setVisibility(View.VISIBLE);
        s9.setVisibility(View.VISIBLE);
        s10.setVisibility(View.GONE);
        s11.setVisibility(View.GONE);
        s12.setVisibility(View.GONE);
        s13.setVisibility(View.GONE);
        s14.setVisibility(View.GONE);
        s15.setVisibility(View.GONE);
        s16.setVisibility(View.GONE);
        s17.setVisibility(View.GONE);

    }

    public void yes9click(View view) {
        s1.setVisibility(View.VISIBLE);
        s2.setVisibility(View.GONE);
        s3.setVisibility(View.GONE);
        s4.setVisibility(View.VISIBLE);
        s5.setVisibility(View.VISIBLE);
        s6.setVisibility(View.VISIBLE);
        s7.setVisibility(View.VISIBLE);
        s8.setVisibility(View.VISIBLE);
        s9.setVisibility(View.VISIBLE);
        s10.setVisibility(View.VISIBLE);
        s11.setVisibility(View.GONE);
        s12.setVisibility(View.GONE);
        s13.setVisibility(View.GONE);
        s14.setVisibility(View.GONE);
        s15.setVisibility(View.GONE);
        s16.setVisibility(View.GONE);
        s17.setVisibility(View.GONE);

    }

    public void no9click(View view) {
        s1.setVisibility(View.VISIBLE);
        s2.setVisibility(View.GONE);
        s3.setVisibility(View.GONE);
        s4.setVisibility(View.VISIBLE);
        s5.setVisibility(View.VISIBLE);
        s6.setVisibility(View.VISIBLE);
        s7.setVisibility(View.VISIBLE);
        s8.setVisibility(View.VISIBLE);
        s9.setVisibility(View.VISIBLE);
        s10.setVisibility(View.GONE);
        s11.setVisibility(View.VISIBLE);
        s12.setVisibility(View.GONE);
        s13.setVisibility(View.GONE);
        s14.setVisibility(View.GONE);
        s15.setVisibility(View.GONE);
        s16.setVisibility(View.GONE);
        s17.setVisibility(View.GONE);

    }

    public void yes10click(View view) {
        s1.setVisibility(View.VISIBLE);
        s2.setVisibility(View.GONE);
        s3.setVisibility(View.GONE);
        s4.setVisibility(View.VISIBLE);
        s5.setVisibility(View.VISIBLE);
        s6.setVisibility(View.VISIBLE);
        s7.setVisibility(View.VISIBLE);
        s8.setVisibility(View.VISIBLE);
        s9.setVisibility(View.VISIBLE);
        s10.setVisibility(View.VISIBLE);
        s11.setVisibility(View.GONE);
        s12.setVisibility(View.GONE);
        s13.setVisibility(View.GONE);
        s14.setVisibility(View.GONE);
        s15.setVisibility(View.GONE);
        s16.setVisibility(View.VISIBLE);
        s17.setVisibility(View.GONE);

    }

    public void no10click(View view) {
        s1.setVisibility(View.VISIBLE);
        s2.setVisibility(View.GONE);
        s3.setVisibility(View.GONE);
        s4.setVisibility(View.VISIBLE);
        s5.setVisibility(View.VISIBLE);
        s6.setVisibility(View.VISIBLE);
        s7.setVisibility(View.VISIBLE);
        s8.setVisibility(View.VISIBLE);
        s9.setVisibility(View.VISIBLE);
        s10.setVisibility(View.VISIBLE);
        s11.setVisibility(View.VISIBLE);
        s12.setVisibility(View.GONE);
        s13.setVisibility(View.GONE);
        s14.setVisibility(View.GONE);
        s15.setVisibility(View.GONE);
        s16.setVisibility(View.GONE);
        s17.setVisibility(View.GONE);

    }

    public void yes11click(View view) {
        s1.setVisibility(View.VISIBLE);
        s2.setVisibility(View.GONE);
        s3.setVisibility(View.GONE);
        s4.setVisibility(View.VISIBLE);
        s5.setVisibility(View.VISIBLE);
        s6.setVisibility(View.VISIBLE);
        s7.setVisibility(View.VISIBLE);
        s8.setVisibility(View.VISIBLE);
        s9.setVisibility(View.VISIBLE);
        s10.setVisibility(View.VISIBLE);
        s11.setVisibility(View.VISIBLE);
        s12.setVisibility(View.GONE);
        s13.setVisibility(View.GONE);
        s14.setVisibility(View.GONE);
        s15.setVisibility(View.GONE);
        s16.setVisibility(View.GONE);
        s17.setVisibility(View.VISIBLE);

    }

    public void no11click(View view) {
        s1.setVisibility(View.VISIBLE);
        s2.setVisibility(View.GONE);
        s3.setVisibility(View.GONE);
        s4.setVisibility(View.VISIBLE);
        s5.setVisibility(View.VISIBLE);
        s6.setVisibility(View.VISIBLE);
        s7.setVisibility(View.VISIBLE);
        s8.setVisibility(View.VISIBLE);
        s9.setVisibility(View.VISIBLE);
        s10.setVisibility(View.VISIBLE);
        s11.setVisibility(View.VISIBLE);
        s12.setVisibility(View.GONE);
        s13.setVisibility(View.VISIBLE);
        s14.setVisibility(View.GONE);
        s15.setVisibility(View.GONE);
        s16.setVisibility(View.GONE);
        s17.setVisibility(View.GONE);

    }
}